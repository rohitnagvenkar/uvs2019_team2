clear all;
close all;
clc;
parameterVehicle;
parameterGNC;